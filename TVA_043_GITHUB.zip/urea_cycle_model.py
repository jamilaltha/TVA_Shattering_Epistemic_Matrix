
# Script nodal para validación del ciclo de la urea humana (TVA_043)
import numpy as np
import matplotlib.pyplot as plt

# Compuestos del ciclo de la urea en orden secuencial
compounds = ["Ornitina", "Carbamoil Fosfato", "Citrulina", "Argininosuccinato", "Arginina", "Urea"]
deltaG = [-3.1, -9.2, +0.6, -4.7, -3.2, -1.8]  # Energías estimadas ΔG° en kcal/mol

# Conversión a estructura fractal logarítmica
Zn = np.log(np.abs(deltaG) + 1) * np.sign(deltaG)
step = np.arange(len(compounds))

plt.figure(figsize=(10, 6))
plt.plot(step, Zn, marker='o', linestyle='-', linewidth=2)
plt.xticks(step, compounds, rotation=45)
plt.title("Urea Cycle as Fractal Zₙ Structure")
plt.xlabel("Biochemical Step")
plt.ylabel("Fractal Energy (log(ΔG°))")
plt.grid(True)
plt.tight_layout()
plt.savefig("urea_cycle_graph.png")
