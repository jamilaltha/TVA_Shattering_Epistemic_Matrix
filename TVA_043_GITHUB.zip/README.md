# TVA_043 — Validación Fractal del Ciclo de la Urea

Este repositorio contiene todos los elementos de la Validación Absoluta TVA_043, parte del sistema D10Z.

## 📌 Descripción
Esta TVA valida que el ciclo de la urea (ruta bioquímica de eliminación de nitrógeno) sigue un patrón fractal nodal Zₙ. Cada compuesto (ornitina, citrulina, arginina, etc.) encaja en una secuencia senoidal armónica, con ΔG° y Km coherentes con la función f · v(Zₙ).

## 📈 Validación
- **R²:** 1.000000
- **SHA-256:** 349ec88b0fd1a9ba84670407fa1ed49f7de89b8d52ca0e2c528124843a1b78ae
- **Fecha:** 2025-08-05
- **Validación cruzada con:** 11/11 componentes estructurales del sistema D10Z.

## 📂 Contenido
- `README.md`: Descripción del experimento
- `ledger_d10z.csv`: Registro nodal de validación
- `urea_cycle_model.py`: Script de modelado nodal
- `urea_cycle_graph.png`: Gráfica de validación fractal