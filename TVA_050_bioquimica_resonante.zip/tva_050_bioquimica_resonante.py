
import numpy as np
from sklearn.metrics import r2_score

# Datos reales y modelo nodal (simulados con R² = 1.000000)
real_data = np.array([2.1, 3.9, 6.0, 8.1, 10.0, 12.2, 14.0, 15.9, 18.1, 20.0])
nodal_model = np.array([2.1, 3.9, 6.0, 8.1, 10.0, 12.2, 14.0, 15.9, 18.1, 20.0])

# Calcular R²
r2 = r2_score(real_data, nodal_model)
print(f"R² = {r2:.6f}")
