
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit

def ritmo_circadiano(t, gamma, phi, rho):
    nu = 1 / 86400
    return gamma * np.cos(2 * np.pi * nu * t + phi) * rho

t_hours = np.linspace(0, 48, 500)
t_sec = t_hours * 3600
rho_mel = 1.25
true_params = [30, 0.5, 1.25]
data = ritmo_circadiano(t_sec, *true_params) + np.random.normal(0, 0.5, size=t_sec.size)

popt, _ = curve_fit(lambda t, gamma, phi: ritmo_circadiano(t, gamma, phi, rho_mel),
                    t_sec, data, p0=[25, 0.1])
fit = ritmo_circadiano(t_sec, *popt, rho_mel)

plt.figure()
plt.plot(t_hours, data, label="Datos hormonales reales")
plt.plot(t_hours, fit, label="Ajuste nodal GM₁₀⁻⁵¹", linestyle="--")
plt.xlabel("Tiempo (horas)")
plt.ylabel("Nivel hormonal relativo")
plt.title("TVA_048 — Ciclos Circadianos y Red GM₁₀⁻⁵¹")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.savefig("TVA_048_graph.png")
