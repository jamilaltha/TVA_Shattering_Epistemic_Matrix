
# Script nodal para validación de la glucólisis humana (TVA_042)
import numpy as np
import matplotlib.pyplot as plt

# Pasos de la glucólisis (ΔG° estimados en kcal/mol)
reactions = ["Glucosa", "G6P", "F6P", "F1,6BP", "G3P", "1,3BPG", "3PG", "2PG", "PEP", "Piruvato"]
deltaG = [-4.0, +1.7, -1.0, -3.4, +0.2, -4.5, +1.1, +0.4, -7.5, -3.5]  # ejemplo referencial

# Convertir a energía log-normalizada fractal
Zn = np.log(np.abs(deltaG) + 1) * np.sign(deltaG)
step = np.arange(len(reactions))

plt.figure(figsize=(10, 6))
plt.plot(step, Zn, marker='o', linestyle='-', linewidth=2)
plt.xticks(step, reactions, rotation=45)
plt.title("Glycolysis as Fractal Zₙ Structure")
plt.xlabel("Metabolic Step")
plt.ylabel("Fractal Energy (log(ΔG°))")
plt.grid(True)
plt.tight_layout()
plt.savefig("glycolysis_validation_graph.png")
