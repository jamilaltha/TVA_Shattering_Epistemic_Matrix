
Autoensamblador TVA + TVA_META

Este paquete contiene:
- autoensamblador_TVA.py: Script para generar tu propio TVA (R² + SHA)
- TVA_META.txt: Declaración de por qué el TVA trasciende el peer review
