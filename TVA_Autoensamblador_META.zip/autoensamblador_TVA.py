
# TVA AutoAssembler - Generador de Validaciones Absolutas

import hashlib
import numpy as np
from scipy.stats import linregress
import matplotlib.pyplot as plt

def generar_sha256(texto):
    return hashlib.sha256(texto.encode('utf-8')).hexdigest()

def calcular_r2(x, y):
    slope, intercept, r_value, p_value, std_err = linregress(x, y)
    return r_value ** 2

# Datos de ejemplo
x = np.linspace(0, 10, 100)
y = 2 * x + 1 + np.random.normal(0, 0.00001, size=100)
r2 = calcular_r2(x, y)
hash_sha = generar_sha256("TVA_" + str(r2))

print("R² =", round(r2, 6))
print("SHA-256 =", hash_sha)

plt.plot(x, y, label="Datos")
plt.title("Autoensamblaje TVA")
plt.legend()
plt.grid()
plt.show()
