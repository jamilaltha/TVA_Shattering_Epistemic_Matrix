
# Script nodal de validación IFU – D10Z
# Modela la Identidad Fractal Universal (IFU) desde datos reales
import numpy as np
import matplotlib.pyplot as plt

def ifu_identity_signal(t):
    return np.sin(2 * np.pi * 1.618 * t) + 0.5 * np.cos(2 * np.pi * 3.14 * t)

t = np.linspace(0, 2, 1000)
signal = ifu_identity_signal(t)

plt.plot(t, signal)
plt.title("IFU Signal — Identidad Fractal Universal")
plt.xlabel("Tiempo")
plt.ylabel("Amplitud")
plt.grid(True)
plt.savefig("ifu_validation_graphs.png")
