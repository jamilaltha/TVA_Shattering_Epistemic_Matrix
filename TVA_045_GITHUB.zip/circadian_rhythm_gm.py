
import numpy as np
import matplotlib.pyplot as plt

# Tiempo en horas (dos días)
t = np.linspace(0, 48, 1000)

# Oscilación circadiana (24h) + modulación GM₁₀⁻⁵¹
circadian = np.sin(2 * np.pi * t / 24)
gm_mod = np.sin(2 * np.pi * t * 10**-51)  # Oscilación imperceptible pero resonante
composite = circadian + 0.1 * gm_mod

plt.figure(figsize=(10, 4))
plt.plot(t, composite, label='Ciclo Circadiano + GM₁₀⁻⁵¹')
plt.xlabel('Tiempo (h)')
plt.ylabel('Intensidad rítmica')
plt.title('Resonancia Nodal en Ciclos Circadianos')
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.savefig('tva_045_graph.png')
plt.show()
