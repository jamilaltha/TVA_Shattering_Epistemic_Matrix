
import numpy as np
import matplotlib.pyplot as plt

# Dominio nodal fractal Zₙ con campo eléctrico simulado
x = np.linspace(0, 2*np.pi, 1000)
Z_n = np.sin(x * 7) * np.exp(-0.1 * x)  # oscilación nodal y decaimiento sináptico

# Campo eléctrico generado
E = Z_n * np.cos(x * 2)

plt.figure(figsize=(10, 4))
plt.plot(x, E, label='Campo eléctrico nodal en neurona piramidal')
plt.xlabel('Posición sináptica (μm)')
plt.ylabel('Intensidad del campo E(t)')
plt.title('Electrodinámica Nodal en Neuronas Piramidales')
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.savefig('tva_044_graph.png')
plt.show()
