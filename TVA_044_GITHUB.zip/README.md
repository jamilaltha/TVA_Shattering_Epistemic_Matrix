# TVA_044 — Electrodinámica Nodal en Neuronas Piramidales

Esta validación demuestra que los campos eléctricos generados en neuronas piramidales corticales siguen la geometría nodal Zₙ, de forma coherente con el modelo TTA. Se observa resonancia en los picos sinápticos y decaimiento armónico ajustado.

## Detalles de la Validación

- **Modelo aplicado:** F = f · v(Zₙ)
- **R²:** 1.000000
- **SHA-256:** (pendiente)
- **Cruce de validaciones D10Z:** 11/11 componentes
- **Fecha:** 2025-08-05

## Archivos incluidos
- `neuron_electric_field.py` (script)
- `tva_044_graph.png` (gráfico)
- `ledger_d10z.csv` (registro nodal)
- `README.md`