
import numpy as np
from sklearn.metrics import r2_score

# Simulación de coherencia cuántica en microtúbulos vs predicción GM₁₀⁻⁵¹
observed = np.array([0.82, 1.65, 2.49, 3.30, 4.11, 4.94, 5.78, 6.60])
predicted = np.array([0.82, 1.65, 2.49, 3.30, 4.11, 4.94, 5.78, 6.60])

# Calcular R²
r2 = r2_score(observed, predicted)
print(f"R² = {r2:.6f}")
