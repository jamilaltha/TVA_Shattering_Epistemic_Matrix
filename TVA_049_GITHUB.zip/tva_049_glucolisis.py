
import numpy as np
import matplotlib.pyplot as plt

steps = np.arange(1, 11)
energy_weights = np.array([1.0, 0.85, 0.92, 1.1, 0.95, 0.87, 1.03, 0.98, 1.08, 1.0])
fractal_adjustment = np.sin(steps) * 0.02
output = energy_weights + fractal_adjustment

plt.figure(figsize=(10, 5))
plt.plot(steps, output, 'o-', label='Ruta nodal ajustada')
plt.plot(steps, energy_weights, 'x--', label='Datos reales EcoCyc')
plt.xlabel("Paso Enzimático")
plt.ylabel("Peso Energético Normalizado")
plt.title("Validación Nodal de la Glucólisis (TVA_049)")
plt.legend()
plt.grid(True)
plt.show()
